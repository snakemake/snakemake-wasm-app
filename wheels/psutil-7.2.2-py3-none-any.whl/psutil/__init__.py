from collections import namedtuple
import os

__all__ = ["cpu_count", "virtual_memory"]

svmem = namedtuple(
    "svmem",
    ["total","available","percent","used","free","active","inactive","buffers","cached","shared","slab"]
)

def cpu_count(logical=True):
    return os.cpu_count() or 1

def virtual_memory():
    total = 0
    available = 0
    used = 0
    free = 0
    percent = 0.0
    return svmem(total, available, percent, used, free, 0, 0, 0, 0, 0, 0)
