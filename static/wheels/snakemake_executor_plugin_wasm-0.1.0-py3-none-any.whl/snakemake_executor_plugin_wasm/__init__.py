from __future__ import annotations

import base64
from dataclasses import dataclass, field
from pathlib import Path
import sys
from typing import Optional

from snakemake_interface_executor_plugins.executors.base import SubmittedJobInfo
from snakemake_interface_executor_plugins.executors.real import RealExecutor
from snakemake_interface_executor_plugins.jobs import JobExecutorInterface
from snakemake_interface_executor_plugins.settings import (
    ExecutorSettingsBase,
    CommonSettings,
    ExecMode,
)
from snakemake_interface_common.exceptions import WorkflowError


@dataclass
class ExecutorSettings(ExecutorSettingsBase):
    worker_url: Optional[str] = field(
        default=None,
        metadata={"help": "URL of the module web worker script."},
    )
    pyodide_base_url: Optional[str] = field(
        default=None,
        metadata={"help": "Base URL of the Pyodide distribution used in workers."},
    )
    wheels_json: Optional[str] = field(
        default=None,
        metadata={"help": "JSON array of wheel URLs to install inside workers."},
    )


common_settings = CommonSettings(
    non_local_exec=False,
    implies_no_shared_fs=False,
    job_deploy_sources=False,
    pass_envvar_declarations_to_cmd=True,
    auto_deploy_default_storage_provider=False,
)


def _plain_list(x) -> list[str]:
    try:
        return [str(v) for v in x]
    except Exception:
        return []


def _plain_mapping(x) -> dict:
    try:
        return dict(x.items())
    except Exception:
        try:
            return dict(x)
        except Exception:
            return {}


class Executor(RealExecutor):
    def get_exec_mode(self):
        return ExecMode.SUBPROCESS

    def get_python_executable(self):
        return sys.executable

    @property
    def job_specific_local_groupid(self):
        return False

    @property
    def cores(self):
        return 1

    def job_args_and_prepare(self, job: JobExecutorInterface) -> dict:
        self.workflow.async_run(job.prepare())

        return {
            "rule_name": job.rule.name,
            "input": _plain_list(job.input),
            "output": _plain_list(job.output),
            "params": _plain_mapping(job.params),
            "wildcards": dict(getattr(job, "wildcards_dict", {})),
            "threads": 1,
            "resources": _plain_mapping(job.resources),
            "log": _plain_list(job.log),
            "workdir": str(getattr(self.workflow, "workdir_init", ".")),
        }

    def _validate_job(self, job: JobExecutorInterface):
        if job.is_group():
            raise WorkflowError("wasm executor does not support group jobs yet")

        threads = int(getattr(job, "threads", 1) or 1)
        if threads != 1:
            raise WorkflowError(
                f"wasm executor currently supports only threads: 1, got {threads}"
            )

    @staticmethod
    def _rule_has_directive_action(job: JobExecutorInterface) -> bool:
        rule = job.rule
        return any(
            (
                getattr(rule, "script", None),
                getattr(rule, "wrapper", None),
                getattr(rule, "cwl", None),
            )
        )

    @staticmethod
    def _resolve_shell_command(job: JobExecutorInterface) -> Optional[str]:
        job_shellcmd = getattr(job, "shellcmd", None)
        if isinstance(job_shellcmd, str) and job_shellcmd.strip():
            return job_shellcmd

        rule_shellcmd = getattr(job.rule, "shellcmd", None)
        if isinstance(rule_shellcmd, str) and rule_shellcmd.strip():
            try:
                return str(job.format_wildcards(rule_shellcmd))
            except Exception:
                return rule_shellcmd

        return None

    def _execute_shell_rule(self, job: JobExecutorInterface):
        command = self._resolve_shell_command(job)
        if not command:
            raise WorkflowError(
                f"wasm executor could not resolve shell command for rule {job.rule.name!r}"
            )
        output_paths = [str(path) for path in _plain_list(job.output) if str(path)]

        try:
            from js import runSnakemakeWasmShellCommand
        except Exception as e:
            raise WorkflowError(
                "Missing JS bridge function runSnakemakeWasmShellCommand in worker global scope"
            ) from e

        async def _run_shell():
            result = await runSnakemakeWasmShellCommand(command, output_paths)
            try:
                result = result.to_py()
            except Exception:
                pass

            if not isinstance(result, dict):
                raise WorkflowError(
                    f"Invalid shell bridge response for rule {job.rule.name!r}: {result!r}"
                )

            exit_code = int(result.get("exitCode", 1))
            if exit_code != 0:
                stdout = str(result.get("stdout", ""))
                stderr = str(result.get("stderr", ""))
                raise WorkflowError(
                    f"Shell command failed for rule {job.rule.name!r} with exit code {exit_code}.\n"
                    f"Command: {command}\n"
                    f"stdout:\n{stdout}\n"
                    f"stderr:\n{stderr}"
                )

            for file_entry in result.get("files", []):
                if not isinstance(file_entry, dict):
                    continue
                rel_path = str(file_entry.get("path", "")).strip()
                if not rel_path:
                    continue
                if rel_path.startswith("/") or ".." in rel_path:
                    raise WorkflowError(f"Rejected unsafe shell output path: {rel_path!r}")

                file_path = Path(rel_path)
                file_path.parent.mkdir(parents=True, exist_ok=True)

                encoding = str(file_entry.get("encoding", "base64"))
                if encoding == "base64":
                    payload = str(file_entry.get("base64", ""))
                    file_path.write_bytes(base64.b64decode(payload))
                elif encoding == "utf-8":
                    file_path.write_text(
                        str(file_entry.get("text", "")), encoding="utf-8"
                    )
                else:
                    raise WorkflowError(
                        f"Unsupported shell output encoding {encoding!r} for {rel_path!r}"
                    )

        self.workflow.async_run(_run_shell())

    def _job_args_for_run_wrapper(self, job: JobExecutorInterface):
        from snakemake.executors.local import DeploymentMethod

        conda_env = (
            job.conda_env.address
            if DeploymentMethod.CONDA
            in self.workflow.deployment_settings.deployment_method
            and job.conda_env
            else None
        )
        container_img = (
            job.container_img_path
            if DeploymentMethod.APPTAINER
            in self.workflow.deployment_settings.deployment_method
            else None
        )
        env_modules = (
            job.env_modules
            if DeploymentMethod.ENV_MODULES
            in self.workflow.deployment_settings.deployment_method
            else None
        )

        benchmark = None
        benchmark_repeats = job.benchmark_repeats or 1
        if job.benchmark is not None:
            benchmark = str(job.benchmark)

        return (
            job.rule,
            job.input._plainstrings(),
            job.output._plainstrings(),
            job.params,
            job.wildcards,
            job.threads,
            job.resources,
            job.log._plainstrings(),
            benchmark,
            benchmark_repeats,
            self.workflow.output_settings.benchmark_extended,
            conda_env,
            container_img,
            self.workflow.deployment_settings.apptainer_args,
            env_modules,
            DeploymentMethod.APPTAINER
            in self.workflow.deployment_settings.deployment_method,
            self.workflow.linemaps,
            self.workflow.execution_settings.debug,
            self.workflow.execution_settings.cleanup_scripts,
            job.shadow_dir,
            job.jobid,
            (
                self.workflow.execution_settings.edit_notebook
                if self.dag.is_edit_notebook_job(job)
                else None
            ),
            self.workflow.conda_base_path,
            job.rule.basedir,
            self.workflow.sourcecache.cache_path,
            self.workflow.sourcecache.runtime_cache_path,
            self.workflow.runtime_paths,
        )

    def _execute_run_rule(self, job: JobExecutorInterface):
        from snakemake.executors.local import run_wrapper

        run_wrapper(*self._job_args_for_run_wrapper(job))

    def run_job(self, job: JobExecutorInterface):
        job_info = SubmittedJobInfo(job=job)

        try:
            self._validate_job(job)
            self.job_args_and_prepare(job)

            self.report_job_submission(job_info)

            if self._resolve_shell_command(job):
                self._execute_shell_rule(job)
                self.report_job_success(job_info)
                return

            if not getattr(job, "is_run", False):
                if self._rule_has_directive_action(job):
                    raise WorkflowError(
                        f"wasm executor supports only run: rules in this mode, got directive-based rule {job.rule.name!r}"
                    )
                self.report_job_success(job_info)
                return

            self._execute_run_rule(job)
            self.report_job_success(job_info)
        except WorkflowError:
            self.report_job_error(job_info, msg="WorkflowError in wasm executor")
            raise
        except Exception as e:
            self.report_job_error(job_info, msg=str(e))
            raise WorkflowError(f"Failed to execute wasm job: {e}") from e

    async def check_active_jobs(self, active_jobs):
        if False:
            yield None

    def cancel_jobs(self, active_jobs):
        return None

    def shutdown(self):
        return None

    def cancel(self):
        return None